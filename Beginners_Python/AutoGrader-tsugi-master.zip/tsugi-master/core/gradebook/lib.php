<?php

require_once "classes.php";

use \Tsugi\Util\LTI;
use \Tsugi\Core\LTIX;

function gradeLoadAll() {
    global $CFG, $USER, $LINK, $PDOX;
    $LTI = LTIX::requireData(LTIX::LINK);
    if ( ! $USER->instructor ) die("Requires instructor role");
    $p = $CFG->dbprefix;

    // Get basic grade data
    $stmt = $PDOX->queryDie(
        "SELECT R.result_id AS result_id, R.user_id AS user_id,
            grade, note, R.json AS json, R.updated_at AS updated_at, displayname, email
        FROM {$p}lti_result AS R
        JOIN {$p}lti_user AS U ON R.user_id = U.user_id
        WHERE R.link_id = :LID
        ORDER BY updated_at DESC",
        array(":LID" => $LINK->id)
    );
    return $stmt;
}

// $detail is either false or a class with methods
function gradeShowAll($stmt, $detail = false) {
    echo('<table border="1">');
    echo("\n<tr><th>Name<th>Email</th><th>Grade</th><th>Date</th></tr>\n");

    while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
        echo('<tr><td>');
        if ( $detail ) {
            $detail->link($row);
        } else {
            echo(htmlent_utf8($row['displayname']));
        }
        echo("</td>\n<td>".htmlent_utf8($row['email'])."</td>
            <td>".htmlent_utf8($row['grade'])."</td>
            <td>".htmlent_utf8($row['updated_at'])."</td>
        </tr>\n");
    }
    echo("</table>\n");
}

// Not cached
function gradeLoad($user_id=false) {
    global $CFG, $USER, $LINK, $PDOX;
    $LTI = LTIX::requireData(array(LTIX::LINK, LTIX::USER));
    if ( ! $USER->instructor && $user_id !== false ) die("Requires instructor role");
    if ( $user_id == false ) $user_id = $USER->id;
    $p = $CFG->dbprefix;

    // Get basic grade data
    $stmt = $PDOX->queryDie(
        "SELECT R.result_id AS result_id, R.user_id AS user_id,
            grade, note, R.json AS json, R.updated_at AS updated_at, displayname, email
        FROM {$p}lti_result AS R
        JOIN {$p}lti_user AS U ON R.user_id = U.user_id
        WHERE R.link_id = :LID AND R.user_id = :UID
        GROUP BY U.email",
        array(":LID" => $LINK->id, ":UID" => $user_id)
    );
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row;
}

function gradeShowInfo($row) {
    echo('<p><a href="grades.php">Back to All Grades</a>'."</p><p>\n");
    echo("User Name: ".htmlent_utf8($row['displayname'])."<br/>\n");
    echo("User Email: ".htmlent_utf8($row['email'])."<br/>\n");
    echo("Last Submision: ".htmlent_utf8($row['updated_at'])."<br/>\n");
    echo("Score: ".htmlent_utf8($row['grade'])."<br/>\n");
    echo("</p>\n");
}

// newdata can be a string or array (preferred)
function gradeUpdateJson($newdata=false) {
    global $CFG, $PDOX, $LINK;
    if ( $newdata == false ) return;
    if ( is_string($newdata) ) $newdata = json_decode($newdata, true);
    $LTI = LTIX::requireData(array(LTIX::LINK));
    $row = gradeLoad();
    $data = array();
    if ( $row !== false && isset($row['json'])) {
        $data = json_decode($row['json'], true);
    }

    $changed = false;
    foreach ($newdata as $k => $v ) {
        if ( (!isset($data[$k])) || $data[$k] != $v ) {
            $data[$k] = $v;
            $changed = true;
        }
    }

    if ( $changed === false ) return;

    $jstr = json_encode($data);

    $stmt = $PDOX->queryDie(
        "UPDATE {$CFG->dbprefix}lti_result SET json = :json, updated_at = NOW()
            WHERE result_id = :RID",
        array(
            ':json' => $jstr,
            ':RID' => $LINK->result_id)
    );
}

