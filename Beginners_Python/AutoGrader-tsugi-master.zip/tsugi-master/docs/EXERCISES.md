
Tsugi Workshop Exercises
========================

If you want to learn to develop for Tsugi or want to give a Tsugi Workshop, 
here are a series of exercises that you can work through to increase your understanding of Tsugi:

* [Installing GIT and Tsugi](https://lti-tools.dr-chuck.com/tsugi/docs/exercises/install/)
* [Inside the Tsugi Grade Tool](https://lti-tools.dr-chuck.com/tsugi/docs/exercises/grade/)
* More coming...
