This code is from:

https://gitorious.org/lightopenid


