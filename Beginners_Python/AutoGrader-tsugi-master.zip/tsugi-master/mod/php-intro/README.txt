There is now a set of legacy code that I will keep around for a while and 
then delete.  The legacy files are:

assn02.php
assn03.php
assn04.php
assn05.php
assn06.php
webauto-old.php

The only place these are used is in my SI664 / SI364 class from Winter 2014.
I will likely delete them before the end of 2014.

