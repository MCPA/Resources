These are for the versions of these programs I used
in Winter 2014 SI664 / SI364 - they can eventually be just discarded
once they have been ported to the new approach for these scripts.

If you want to support the old URLs, copy these files into the ..
folder - they have no name conflicts with the files in the main 
folder.

-- Chuck
Sat Sep 13 21:18:02 EDT 2014
