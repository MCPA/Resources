<?php

$REGISTER_LTI2 = array(
"name" => "PHP Autograder",
"FontAwesome" => "fa-code",
"short_name" => "PHP Autograder",
"description" => "This is an autograder for PHP assignments from www.php-intro.com.",
"messages" => array("launch", "launch_grade")
);

