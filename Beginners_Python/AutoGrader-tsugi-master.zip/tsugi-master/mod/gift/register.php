<?php

$REGISTER_LTI2 = array(
"name" => "Quizzes",
"FontAwesome" => "fa-question-circle",
"short_name" => "Quizzes",
"description" => "This tool provides a quiz engine that supports the GIFT format. GIFT is a line-oriented plain text question format that is simple to understand and esaily edited by hand or even stored in a repository like github.",
"messages" => array("launch", "launch_grade")
);

