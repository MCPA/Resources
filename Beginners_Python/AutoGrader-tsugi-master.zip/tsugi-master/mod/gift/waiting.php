<div style="
position: relative;
  top: 50%;
  left: 50%;
  transform: translateY(-50%);">
<img src="ajax-loader.gif">
</div>
