These are just some hacks that I keep around 
to bluedgeon various export formatss to
help some of the manual editing efforts.

