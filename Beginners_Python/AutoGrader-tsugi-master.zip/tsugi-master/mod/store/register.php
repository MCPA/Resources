<?php

$REGISTER_LTI2 = array(
"name" => "Application Store",
"FontAwesome" => "fa-shopping-cart",
"short_name" => "App Store",
"description" => "This tool provides an shopping cart for LMS systems that support the the IMS Content Item protocol.  When this tool is properly placed in an LMS, the user can easily select and place Tsugi tools from this server in their LMS.",
"messages" => array("select_link")
);

