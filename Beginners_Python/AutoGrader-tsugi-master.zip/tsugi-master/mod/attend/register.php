<?php

$REGISTER_LTI2 = array(
"name" => "Simple Attendance Tool",
"FontAwesome" => "fa-server",
"short_name" => "Attendance Tool",
"description" => "This is a simple attendance tool that allows the instructor to set a code and the students enter the code."
);
