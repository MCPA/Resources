<?php

$REGISTER_LTI2 = array(
"name" => "HTML5 Autograder",
"FontAwesome" => "fa-html5",
"short_name" => "HTML5 Autograder",
"description" => "This is an autograder for HTML assignments from www.intro-webdesign.com.",
"messages" => array("launch", "launch_grade")
);

