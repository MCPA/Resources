<?php

$REGISTER_LTI2 = array(
"name" => "Python Autograder",
"FontAwesome" => "fa-check-square-o",
"short_name" => "Python Autograder",
"description" => "This is an autograder for the assignments from www.pythonlearn.com (Python for Informatics).",
"messages" => array("launch", "launch_grade")
);

