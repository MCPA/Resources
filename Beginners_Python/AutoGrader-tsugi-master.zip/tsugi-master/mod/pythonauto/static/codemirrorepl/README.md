These files are from skulpt.org - they are based on a fork of CodeMirror

We keep the regular codemirror in place so we can track that as it goes
forward.

/Chuck
Wed Apr  2 19:06:53 EDT 2014

