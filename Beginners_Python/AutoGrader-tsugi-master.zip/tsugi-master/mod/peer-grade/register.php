<?php

$REGISTER_LTI2 = array(
"name" => "Peer-Graded Dropbox",
"FontAwesome" => "fa-code-fork",
"short_name" => "Peer Grader",
"description" => "This tool provides a structured dropbox that can take images, URLs, text and code.  These tools can be peer-graded, instructor graded, or a blend of peer and instructor graded assignments.",
"messages" => array("launch", "launch_grade")
);

