<?php

$REGISTER_LTI2 = array(
"name" => "Course Map",
"FontAwesome" => "fa-map-marker",
"short_name" => "Course Map",
"description" => "This provides a simple Google map for a course where participants can indicate their location and control how much information they release to those viewing the map."
);

