<?php

$REGISTER_LTI2 = array(
"name" => "SQL Autograder",
"FontAwesome" => "fa-database",
"short_name" => "SQL Autograder",
"description" => "This is an autograder for PHP assignments from www.sql-intro.com.",
"messages" => array("launch", "launch_grade"),
);

