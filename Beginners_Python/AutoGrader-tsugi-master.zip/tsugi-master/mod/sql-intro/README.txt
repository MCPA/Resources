Names from:


The Most Popular Names in Scotland, 2007 - Detailed Tables

http://www.nrscotland.gov.uk/files/statistics/pop-names-07-t4.csv

Via:

http://stackoverflow.com/questions/1452003/plain-computer-parseable-lists-of-common-first-names

