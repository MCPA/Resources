<?php

$REGISTER_LTI2 = array(
"name" => "Python Data",
"FontAwesome" => "fa-hdd-o",
"short_name" => "Python Data Autograder",
"description" => "This is an autograder for PHP data assignments for chapters 11-14 www.pythonlearn.com.",
"messages" => array("launch", "launch_grade"),
);

