<?php

$REGISTER_LTI2 = array(
"name" => "Grade Book",
"FontAwesome" => "fa-area-chart",
"short_name" => "Grade Book",
"description" => "This tool allows both the students and instructors to view their grades for this course across all the LTI tools hosted on this server.  This tool also provides simple grade review and maintenance tools for instructors."
);

