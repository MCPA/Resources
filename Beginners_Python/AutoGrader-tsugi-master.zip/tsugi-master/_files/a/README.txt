This will accrete sharded subfolders of the file content.

