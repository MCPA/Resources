<?php

$REGISTER_LTI2 = array(
"name" => "Settings Unit Test Tool",
"FontAwesome" => "fa-database",
"short_name" => "Settings Test",
"description" => "This tool allows you to exercise the LTI 2.x JSON Settings API."
);

