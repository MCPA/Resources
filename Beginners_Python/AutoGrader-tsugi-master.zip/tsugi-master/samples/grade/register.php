<?php

$REGISTER_LTI2 = array(
"name" => "Grade Unit Test Tool",
"FontAwesome" => "fa-soccer-ball-o",
"short_name" => "Grade Test",
"description" => "This tool allows you to exercise the LTI 2.x JSON grade return API.",
"messages" => array("launch", "launch_grade")
);

