<?php

$REGISTER_LTI2 = array(
"name" => "Caliper Unit Test Tool",
"FontAwesome" => "fa-cubes",
"short_name" => "Caliper Test",
"description" => "This tool tests the pre-production Caliper API from Canvas."
);

